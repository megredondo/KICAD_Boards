# LEDs.pretty

This library contains PCB footprints for various LEDs (light emitting diodes) and associated devices
