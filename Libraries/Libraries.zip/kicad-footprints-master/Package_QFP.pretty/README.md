# Housings_QFP.pretty

This repository contains various Quad-Flat-Package footprints - https://en.wikipedia.org/wiki/Quad_Flat_Package
